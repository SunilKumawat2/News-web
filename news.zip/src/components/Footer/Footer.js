import React from 'react'
import { Link } from 'react-router-dom'
const Footer = () => {
  return (
    <div>
      <footer>
                    {/* <!-- footer-bottom aera --> */}
                    <div className="footer-bottom-area bg-white text-muted">
                        <div className="container">
                            <div className="footer-border pt-20 pb-20">
                                <div className="row d-flex align-items-center justify-content-between">
                                    <div className="col-12">
                                        <div className="footer-copy-right">
                                            <p className="font-small text-muted">© 2023, News | All rights reserved | Design by
                                                <Link
                                                    to="/" target="_blank">TheInk.com</Link></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    {/* <!-- Footer End--> */}
                </footer>
    </div>
  )
}

export default Footer
