import React from "react";
import { Link } from "react-router-dom";
import "../../assets/css/color.css";
import "../../assets/css/responsive.css";
import "../../assets/css/style.css";
import "../../assets/css/widgets.css";
import "../../assets/css/vendor/slicknav.css";
import newsLogo from "../../assets/images/NewsLogo2.png";
import { BsFacebook } from "react-icons/bs";
import { AiOutlineInstagram, AiOutlineTwitter } from "react-icons/ai";
import { FcGoogle } from "react-icons/fc";
// import axios from "axios";
// import { API_BASE_URL } from "../../config/Config";
const Header = () => {
  // const [CategorieList, setCategorieList] = useState([]);
  // const [webDashBoard, setWebDashBoard] = useState({
  //   reals: [],
  //   posts: [],
  //   all_posts: [],
  //   slider: [],
  //   tranding_post: [],
  // });
  // const GetCategorieList = async () => {
  //   await axios.get(`${API_BASE_URL}/category-list`).then((response) => {
  //     setCategorieList(response.data.data);
  //   });
  // };
  // const GetWebDashBoardCategory = async (id) => {
  //   await axios
  //     .get(`${API_BASE_URL}/web-dashboard?category_id=${id}`)
  //     .then((response) => {
  //       setWebDashBoard(response.data.data);
  //     })
  //     .catch((error) => {
  //       console.log(error);
  //     });
  // };
  // useEffect(() => {
  //   GetCategorieList();
  //   GetWebDashBoardCategory(1);
  // }, []);

  return (
    <div className="main-wrap">
      {/* <!--Offcanvas sidebar--> */}
      {/* {isCanvasOpen && (
        <aside
          id="sidebar-wrapper"
          className="custom-scrollbar p-5 offcanvas-sidebar position-right
                ps ps--active-x ps--active-y d-block d-md-none d-lg-none d-xl-none"
        >
          <button className="off-canvas-close" onClick={closeCanvas}>
            <i className="ti-close"></i>
          </button>
          <div className="sidebar-inner">
            <div className="sidebar-widget widget_categories border-radius-10 bg-white mb-30">
              <div className="widget-header position-relative mb-15">
                <h5 className="widget-title">
                  <strong>Categories</strong>
                </h5>
              </div>
              <div
              
                className='menu-container'
              >
                {CategorieList?.map((result) => {
                  return (
                    <>
                      <ul className="font-small text-muted">
                        <li className="cat-item cat-item-2">
                          <Link to="/">
                            <div
                              onClick={() => GetWebDashBoardCategory(result.id)}
                            >
                              <img
                                src={result.image}
                                style={{
                                  width: "30px",
                                  height: "30px",
                                  borderRadius: "50%",
                                  marginRight: "15px",
                                }}
                                alt=""
                              />
                              {result.title}
                            </div>
                          </Link>
                        </li>
                      </ul>
                    </>
                  );
                })}
              </div>
            </div>
          </div>
          <div className="ps__rail-x">
            <div class="ps__thumb-x"></div>
          </div>
          <div className="ps__rail-y">
            <div className="ps__thumb-y"></div>
          </div>
        </aside>
      )} */}
      <header
        className="main-header header-style-2 mb-40"
        style={{
          position: "fixed",
          top: "0",
          left: "0",
          zIndex: "999",
          width: "100%",
        }}
      >
        <div className="header-bottom header-sticky background-white text-center">
          <div className="scroll-progress gradient-bg-1"></div>
          <div className="container">
            <div className="row">
              <div className="col-10 col-lg-2 col-md-3">
                <div className="header-logo d-none d-lg-block">
                  <Link to="/">
                    <img className="logo-img d-inline" src={newsLogo} alt="" />
                  </Link>
                </div>
                <div className="logo-tablet d-md-inline d-lg-none d-none">
                  <Link to="/">
                    <img className="logo-img d-inline" src={newsLogo} alt="" />
                  </Link>
                </div>
                <div className="logo-mobile d-block d-md-none">
                  <Link to="/">
                    <img className="logo-img d-inline" src={newsLogo} alt="" />
                  </Link>
                </div>
              </div>
              <div className="col-12 col-lg-10 col-md-9 main-header-navigation">
                {/* <!-- Main-menu --> */}
                <div className="main-nav float-md-right ">
                  {/* <ul
                    className="mobi-menu d-none menu-3-columns"
                    id="navigation"
                  >
                    <li className="cat-item cat-item-2">
                      <Link to="/">All News</Link>
                    </li>
                    <li className="cat-item cat-item-4">
                      <Link to="/">Politics</Link>
                    </li>
                    <li className="cat-item cat-item-5">
                      <Link to="/">Sports</Link>
                    </li>
                    <li className="cat-item cat-item-6">
                      <Link to="/">Movies</Link>
                    </li>
                    <li className="cat-item cat-item-7">
                      <Link to="/">Automotive</Link>
                    </li>
                    <li className="cat-item cat-item-2">
                      <Link to="/">Education</Link>
                    </li>
                  </ul> */}
                  <nav>
                    <ul className="main-menu">
                      <li>
                        <BsFacebook className="BsFacebook" />
                      </li>
                      <li>
                        <AiOutlineInstagram className="instagram-gradient" />
                      </li>
                      <li className="AiOutlineTwitter">
                        <AiOutlineTwitter />
                      </li>
                      <li>
                        <FcGoogle className="FcGoogle" />
                      </li>
                      {/* <li><AiOutlineGoogle/></li>
                      <li>h</li> */}
                      {/* <li>
                                                    <Link to="/"><span className="mr-15">
                                                        <i className='ti-home' style={{fontSize:"18px"}}></i>
                                                        <ion-icon name="home-outline" role="img"
                                                         className="md hydrated"
                                                            aria-label="home outline"></ion-icon>
                                                    </span>Home</Link>
                                                </li> */}
                    </ul>
                  </nav>
                </div>

                {/* <!-- Off canvas --> */}
                {/* <div className="off-canvas-toggle-cover">
                  <div
                    className="off-canvas-toggle hidden d-inline-block
                                         ml-15"
                    id="off-canvas-toggle"
                  >
                    <FaBars
                      name="grid-outline"
                      onClick={toggleCanvas}
                      role="img"
                      className="md hydrated  d-block d-md-none d-lg-none d-xl-none"
                      aria-label="grid outline"
                    />
                  </div>
                </div> */}
              </div>
            </div>
          </div>
        </div>
      </header>
    </div>
  );
};

export default Header;
