import React from "react";
import { Routes, Route } from "react-router-dom";
import Home from "../pages/Home";
import NewsDetails from "../pages/NewsDetails";
import Header from "../Header/Header";
import Footer from "../Footer/Footer";
const AllRoutes = () => {
  return (
    <div>
      <Routes>
        <Route path="/Header" element={<Header />} />
        <Route path="/" element={<Home />} />
        <Route path="/NewsDetails/:id" element={<NewsDetails />} />
        <Route path="/Footer" element={<Footer />} />
      </Routes>
    </div>
  );
};

export default AllRoutes;
