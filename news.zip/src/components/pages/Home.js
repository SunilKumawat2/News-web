import React, { useEffect, useState } from "react";
import "../../assets/css/color.css";
import "../../assets/css/responsive.css";
import "../../assets/css/style.css";
import "../../assets/css/widgets.css";
import { Link, useNavigate } from "react-router-dom";
import Header from "../Header/Header";
import moment from "moment";
import Footer from "../Footer/Footer";
import axios from "axios";
import { API_BASE_URL } from "../../config/Config";
import Loader from "../loader/Loader";
import { FaBars } from "react-icons/fa";
import Dropdown from "react-bootstrap/Dropdown";
import Carousel from "react-bootstrap/Carousel";
import hindi from "../../assets/images/hindi.svg";
import english from "../../assets/images/english.svg";
const Home = () => {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [content, setContent] = useState("");
  const [selectedLanguage, setSelectedLanguage] = useState(
    localStorage.getItem("lang")
  );

  useEffect(() => {
    // Simulate data loading
    setTimeout(() => {
      setContent("Your content here");
      setIsLoading(false);
    }, 1000); // Simulated loading time
  }, []);

  const [CategorieList, setCategorieList] = useState([]);
  const [webDashBoard, setWebDashBoard] = useState({
    reals: [],
    posts: [],
    all_posts: [],
    slider: [],
    tranding_post: [],
    category: [],
  });

  //search functionality start
  const [searchKey, setSearchKey] = useState("");
  const GetSearchData = async () => {
    const ApiData = {
      language: localStorage.getItem("lang")
        ? localStorage.getItem("lang")
        : "En",
    };
    await axios
      .get(`${API_BASE_URL}/web-dashboard?search=${searchKey}&language=${ApiData.language}`)
      .then((SearchDataResponse) => {
        setWebDashBoard(SearchDataResponse.data.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  // This Methods For the GetWebDashBoard
  const GetWebDashBoard = async () => {
    let ApiData = {
      language: localStorage.getItem("lang")
        ? localStorage.getItem("lang")
        : "En",
    };
    await axios
      .get(`${API_BASE_URL}/web-dashboard?language=${ApiData.language}`)
      .then((response) => {
        setWebDashBoard(response.data.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };
  // This Function for the Categroy wise Data Show
  const GetWebDashBoardCategory = async (id) => {
    let ApiData = {
      language: localStorage.getItem("lang")
        ? localStorage.getItem("lang")
        : "En",
    };
    await axios
      .get(
        `${API_BASE_URL}/web-dashboard?category_id=${id}&language=${ApiData.language}`
      )
      .then((response) => {
        setWebDashBoard(response.data.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };
  // This Methods for the Get CateGoriesList
  const GetCategorieList = async () => {
    await axios.get(`${API_BASE_URL}/category-list`).then((response) => {
      setCategorieList(response.data.data);
    });
  };
  // This UseEffect Call for the Show the data GetCategorieList
  useEffect(() => {
    GetCategorieList();
    GetWebDashBoard();
    GetWebDashBoardCategory();
  }, []);
  // This UseEffect Call for the Show the data GetSearchData
  useEffect(() => {
    if (searchKey) {
      setTimeout(() => {
        GetSearchData();
      }, 1000);
    }
  }, [searchKey]);
  // This UseEffect Call for the Show the data GetWebDashBoard and GetWebDashBoardCategory
  useEffect(() => {
    const lang = localStorage.getItem("lang");
    if (lang) {
      GetWebDashBoard();
      GetWebDashBoardCategory();
    }
  }, [localStorage.getItem("lang")]);

  const handleLanguageDropdown = (eventKey) => {
    console.log("selected lang", eventKey);
    localStorage.setItem("lang", eventKey);
    setSelectedLanguage(eventKey);
  };

  // This Methods for the ScrollDown And ScrollUp
  const [showTopIcon, setShowTopIcon] = useState(true);
  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  };
  // const redirectToDetail = (id) => {
  //   const dataToSend = {
  //     name: id,
  //   };
  //   navigate("/NewsDetails/:id", { state: { data: dataToSend } });
  // };

  const scrollToBottom = () => {
    window.scrollTo({
      top: document.documentElement.scrollHeight,
      behavior: "smooth",
    });
  };

  const handleScroll = () => {
    const scrollTop = window.scrollY;
    setShowTopIcon(scrollTop > 0);
  };

  useEffect(() => {
    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  const [isCanvasOpen, setIsCanvasOpen] = useState(false);
  const toggleCanvas = () => {
    setIsCanvasOpen(!isCanvasOpen);
    console.log("isCanvasOpen", isCanvasOpen);
  };

  const closeCanvas = () => {
    console.log("out");
    setIsCanvasOpen(false);
  };
  const dropdownStyle = {
    // Replace 'blue' with your desired background color
    marginTop: "70px",
  };
  return (
    <div>
      <div className={`main-wrap ${isCanvasOpen ? "canvas-opened" : ""}`}>
        {isCanvasOpen && (
          <aside
            id="sidebar-wrapper"
            className="custom-scrollbar p-5 offcanvas-sidebar position-right
                ps ps--active-x ps--active-y d-block d-md-none d-lg-none d-xl-none"
          >
            <button className="off-canvas-close" onClick={closeCanvas}>
              <i className="ti-close"></i>
            </button>
            <div className="sidebar-inner">
              <div className="sidebar-widget widget_categories border-radius-10 bg-white mb-30">
                <div className="widget-header position-relative mb-15">
                  <h5 className="widget-title">
                    <strong>Categories</strong>
                  </h5>
                </div>
                <div className="menu-container" onClick={closeCanvas}>
                  {CategorieList?.map((result) => {
                    return (
                      <>
                        <ul className="font-small text-muted">
                          <li className="cat-item cat-item-2">
                            <Link to="/">
                              <div
                                onClick={() =>
                                  GetWebDashBoardCategory(result?.id)
                                }
                              >
                                <img
                                  src={result?.image}
                                  style={{
                                    width: "30px",
                                    height: "30px",
                                    borderRadius: "50%",
                                    marginRight: "15px",
                                  }}
                                  alt=""
                                />
                                {result?.title}
                              </div>
                            </Link>
                          </li>
                        </ul>
                      </>
                    );
                  })}
                </div>
              </div>
            </div>
            <div className="ps__rail-x">
              <div class="ps__thumb-x"></div>
            </div>
            <div className="ps__rail-y">
              <div className="ps__thumb-y"></div>
            </div>
          </aside>
        )}
        {/* <!-- Main Header --> */}
        <Header />
        {/* off-canvas-toggle-cover */}
        <div className="off-canvas-toggle-cover">
          <div
            className="off-canvas-toggle hidden d-inline-block
                                         ml-15"
            id="off-canvas-toggle"
          >
            <FaBars
              name="grid-outline"
              onClick={toggleCanvas}
              role="img"
              className="md hydrated  d-block d-md-none d-lg-none d-xl-none"
              aria-label="grid outline"
            />
          </div>
        </div>
        <div>
          {/* This is Catagory section under the header section */}
          <div className="d-none d-md-block d-lg-block">
            <div className="CatagoryHeader box-shadow bg-white border-top">
              <div className="CatagoryHeaderContent">
                <ul className="font-small nav">
                  {CategorieList?.map((result, index) => {
                    return (
                      <>
                        <li className="cat-item cat-item-2">
                          <Link to="/">
                            <div
                              onClick={() =>
                                GetWebDashBoardCategory(result?.id)
                              }
                            >
                              <div
                                style={{
                                  display: "flex",
                                  alignItems: "center",
                                }}
                              >
                                <img
                                  src={result?.image}
                                  style={{
                                    width: "27px",
                                    height: "27px",
                                    borderRadius: "50%",
                                    marginRight: "10px",
                                  }}
                                  alt=""
                                />
                                <span>{result?.title}</span>
                              </div>
                            </div>
                          </Link>
                        </li>
                      </>
                    );
                  })}
                </ul>
              </div>
            </div>
          </div>
        </div>
        {/* <!-- Search --> */}
        <Dropdown
          onSelect={handleLanguageDropdown}
          value={selectedLanguage}
          style={dropdownStyle}
          className="bootstrapDropdown"
        >
          <Dropdown.Toggle
            className="DropdownToggle"
            style={{ color: "grey", backgroundColor: "#f7f8f9" }}
          >
            {selectedLanguage ? (
              selectedLanguage == "Hi" ? (
                <img src={hindi} style={{ width: "50px" }} alt="" />
              ) : (
                <img src={english} style={{ width: "50px" }} alt="" />
              )
            ) : (
              <img src={hindi} style={{ width: "50px" }} alt="" />
            )}
          </Dropdown.Toggle>

          <Dropdown.Menu>
            <Dropdown.Item eventKey="Hi">
              <img src={hindi} style={{ width: "50px" }} alt="" />
            </Dropdown.Item>
            <Dropdown.Item eventKey="En">
              <img src={english} style={{ width: "50px" }} alt="" />
            </Dropdown.Item>
          </Dropdown.Menu>
        </Dropdown>
        <div className="header-style-2 header_searchs">
          <div className="siderbar-widget">
            <form
              action="#"
              method="get"
              className="search-form d-lg-inline float-right
               position-relative m-xs-0 mr-30"
              onChange={(e) => GetSearchData(e.target.value)}
              onSubmit={(e) => {
                e.preventDefault(); // Prevent the default form submission
                GetSearchData(searchKey); // Handle the search action here
              }}
            >
              <input
                type="text"
                className="search_field"
                placeholder="Search"
                value={searchKey}
                onChange={(e) => setSearchKey(e.target.value)}
              />
              <span className="search-icon">
                <i
                  className="ti-search mr-5"
                  // onClick={(e) => GetSearchData(e.target.value)}
                ></i>
              </span>
            </form>
          </div>
        </div>

        {/* <!-- Main Wrap Start --> */}
        {isLoading ? (
          <Loader />
        ) : (
          <main className="position-relative" style={{ marginTop: "130px" }}>
            <div className="container main-container">
              <div className="row">
                <div
                  className="col-lg-2 col-md-3 primary-sidebar sticky-sidebar
               sidebar-left order-2 order-md-1"
                >
                  {/* <div className="theiaStickySidebar">
                    <div className="sidebar-widget1 widget_categories border-radius-10 bg-white mb-30">
                      <div className="widget-header position-relative mb-15">
                        <h5 className="widget-title">
                          <strong>Categories</strong>
                        </h5>
                      </div>
                      {CategorieList?.map((result) => {
                        return (
                          <>
                            <ul className="font-small text-muted">
                              <li className="cat-item cat-item-2">
                                <Link to="/">
                                  <div
                                    onClick={() =>
                                      GetWebDashBoardCategory(result?.id)
                                    }
                                  >
                                    <img
                                      src={result?.image}
                                      style={{
                                        width: "30px",
                                        height: "30px",
                                        borderRadius: "50%",
                                        marginRight: "15px",
                                      }}
                                      alt=""
                                    />
                                    {result?.title}
                                  </div>
                                </Link>
                              </li>
                            </ul>
                          </>
                        );
                      })}
                    </div>
                  </div> */}
                </div>
                {/* <!-- main content --> */}
              </div>
              <div className="home_main_content">
                <div className="row">
                  <div className="col-12 col-lg-8 col-md-12">
                    <div className="latest-post mb-50">
                      <div className="widget-header position-relative mb-30"></div>
                      <div className="loop-list-style-1">
                        <Carousel className="carousel_cus">
                          {webDashBoard?.slider?.length > 0 ? (
                            webDashBoard.slider.map((item, index) => (
                              <Carousel.Item
                                className="carousel_sliders"
                                key={index}
                                // onClick={() => {
                                //   redirectToDetail(item?.post_id);
                                // }}
                              >
                                <div className="img-hover-slide border-radius-15 mb-30 position-relative overflow-hidden">
                                  <Link to={`/NewsDetails/${item?.post_id}`}>
                                    <div className="post-title">
                                      <p className="Carousel_Caption">
                                        {item?.title}
                                      </p>
                                    </div>

                                    <img
                                      className="d-block CarouselImg"
                                      src={item?.image}
                                      alt={`Slide ${index + 1}`}
                                      style={{
                                        objectFit: "cover",
                                        width: "100%",
                                        height: "100%",
                                      }}
                                    />
                                  </Link>
                                </div>
                                {/* <div className="pr-10 pl-10">
                                  <div className="entry-meta mb-30">
                                    <Link className="entry-meta meta-0" to="#">
                                      <span className="post-in font-x-small">
                                        {item?.get_category?.title}
                                      </span>
                                      <span className="text-grey">
                                        {item?.tags}
                                      </span>
                                      <span className="post-by">
                                        By{" "}
                                        <Link to="#">{item?.author_name}</Link>
                                      </span>
                                      <span className="post-on">
                                        {moment(item?.created_at).format(
                                          "DD-MM-YYYY"
                                        )}
                                      </span>
                                    </Link>
                                    <div className="float-right font-small">
                                      <span>
                                        <span className="mr-10 text-muted">
                                          <i
                                            className="fa fa-eye"
                                            aria-hidden="true"
                                          ></i>
                                        </span>
                                        {item?.views_count}
                                      </span>
                                      <span className="ml-30">
                                        <span className="mr-10 text-muted">
                                          <i
                                            className="fa fa-comment"
                                            aria-hidden="true"
                                          ></i>
                                        </span>
                                        {item?.comment_count}
                                      </span>
                                    </div>
                                  </div>

                                  <div className="mb-20 overflow-hidden">
                                    <div className="entry-meta meta-1 font-x-small color-grey float-left text-uppercase"></div>
                                    <div className="float-right"></div>
                                  </div>
                                </div> */}
                              </Carousel.Item>
                            ))
                          ) : (
                            <h3>No data available here...</h3>
                          )}
                        </Carousel>

                        {/* This Function use for the show the complete data */}
                        {webDashBoard?.posts?.slice(0).map((result) => {
                          return (
                            <>
                              <Link to={`/NewsDetails/${result?.id}`}>
                                <article
                                  key={result?.id}
                                  className="p-10 background-white border-radius-10 mb-30 wow fadeIn animated post_data"
                                  // onClick={() => {
                                  //   redirectToDetail(result?.id);
                                  // }}
                                >
                                  <div className="d-flex">
                                    <div className="post-thumb d-flex mr-15 border-radius-15 img-hover-scale">
                                      {result?.file_type == "image" ? (
                                        <Link
                                          className="color-white"
                                          to={`/NewsDetails/${result?.id}`}
                                        >
                                          <img
                                            className="border-radius-15"
                                            src={result?.get_images[0]?.image}
                                            alt=""
                                          />
                                        </Link>
                                      ) : (
                                        <Link
                                          className="color-white"
                                          to={`/NewsDetails/${result?.id}`}
                                        >
                                          <img
                                            className="border-radius-15"
                                            src={result?.thumbnel}
                                            alt=""
                                          />
                                        </Link>
                                      )}
                                    </div>
                                    <div className="post-content media-body">
                                      <div className="entry-meta mb-15 mt-10">
                                        <Link
                                          className="entry-meta meta-2"
                                          to="#"
                                        ></Link>
                                      </div>
                                      <h5 className="post-title mb-15 text-limit-2-row">
                                        <span className="post-format-icon">
                                          <i className="ti-camera"></i>
                                        </span>
                                        <Link to={`/NewsDetails/${result?.id}`}>
                                          {result?.title}
                                        </Link>
                                      </h5>
                                      <div
                                        className="entry-meta meta-1 font-x-small 
                                      color-grey float-left text-uppercase"
                                      >
                                        <span
                                          className="post-in font-x-small p-2 rounded-pill"
                                          style={{
                                            color: `${result?.get_category?.color_code}`,
                                          }}
                                        >
                                          {result?.get_category?.title}
                                        </span>
                                        <span className="post-by">
                                          By{" "}
                                          <Link to="#">
                                            {result?.author_name}
                                          </Link>
                                        </span>
                                        <span className="post-on">
                                          {moment(result?.created_at).format(
                                            "DD-MM-YYYY"
                                          )}
                                        </span>
                                        <span className="time-reading">
                                          {result?.state}
                                        </span>
                                      </div>
                                    </div>
                                  </div>
                                </article>
                              </Link>
                            </>
                          );
                        })}
                      </div>
                      {/* This section show the data category wise in the home page  */}
                      <div>
                        {webDashBoard?.category?.map((categoryResult) => {
                          const hasPosts = categoryResult.get_posts.length > 0;
                          return (
                            <>
                              {hasPosts && (
                                <ul
                                  className="webDashBoardcategory_ul"
                                  key={categoryResult?.id}
                                >
                                  <li>
                                    <Link to="/">
                                      <div
                                        className="webDashBoardcategory_title_images"
                                        onClick={() =>
                                          GetWebDashBoardCategory(
                                            categoryResult?.id
                                          )
                                        }
                                      >
                                        <img
                                          src={categoryResult?.image}
                                          style={{
                                            width: "35px",
                                            height: "35px",
                                            borderRadius: "50%",
                                            marginRight: "15px",
                                          }}
                                          alt=""
                                        />
                                        {categoryResult?.title}
                                      </div>
                                    </Link>

                                    <div className="webDashBoardcategory_Wise_Data">
                                      {categoryResult?.get_posts?.map(
                                        (post) => (
                                          <div
                                            className="webDashBoardcategory_Wise_Data_div"
                                            // onClick={() => {
                                            //   redirectToDetail(post?.id);
                                            // }}
                                          >
                                            <div>
                                              {webDashBoard?.category?.map(
                                                (categoryResult, index) =>
                                                  index == 0 && (
                                                    <article
                                                      className="first-post p-10 background-white 
                                                    border-radius-10 mb-30 wow fadeIn animated"
                                                    >
                                                      <h4 className="post-title mb-20">
                                                        <span className="post-format-icon">
                                                          <i className="ti-camera"></i>
                                                        </span>
                                                        <Link
                                                          to={`/NewsDetails/${post?.id}`}
                                                        >
                                                          {post?.title}
                                                        </Link>
                                                      </h4>
                                                      <div
                                                        className="img-hover-slide border-radius-15 
                                                      mb-30 position-relative overflow-hidden"
                                                      >
                                                        <Link
                                                          to={`/NewsDetails/${post?.id}`}
                                                        >
                                                          {post?.file_type ==
                                                          "image" ? (
                                                            <img
                                                              src={
                                                                post?.get_images
                                                                  ?.image
                                                              }
                                                              alt="post-slider"
                                                            />
                                                          ) : (
                                                            <img
                                                              src={
                                                                post?.thumbnel
                                                              }
                                                              alt="post-slider"
                                                            />
                                                          )}
                                                        </Link>
                                                      </div>
                                                      <div className="pr-10 pl-10">
                                                        <div className="entry-meta mb-30">
                                                          <Link className="entry-meta meta-0">
                                                            <span className="post-in background2 text-primary font-x-small">
                                                              {post?.tags}
                                                            </span>
                                                            <span className="post-by">
                                                              By{" "}
                                                              <Link to="# ">
                                                                {
                                                                  post?.author_name
                                                                }
                                                              </Link>
                                                            </span>
                                                          </Link>
                                                          <div className="float-right font-small">
                                                            <span>
                                                              {/* <span className="mr-10 text-muted">
                                                                <i
                                                                  className="fa fa-eye"
                                                                  aria-hidden="true"
                                                                ></i>
                                                              </span> */}
                                                              {/* {post?.like_count} */}
                                                            </span>
                                                            <span className="ml-30">
                                                              <span className="mr-10 text-muted">
                                                                <i
                                                                  className="fa fa-comment"
                                                                  aria-hidden="true"
                                                                ></i>
                                                              </span>
                                                              {
                                                                post?.comment_count
                                                              }
                                                            </span>
                                                          </div>
                                                        </div>
                                                        {/* <h4 className="post-title mb-20">
                                                          <span className="post-format-icon">
                                                            <i className="ti-camera"></i>
                                                          </span>
                                                          <Link        to={`/NewsDetails/${post?.id}`}>
                                                            {post?.title}
                                                          </Link>
                                                        </h4> */}
                                                        <div className="mb-20 overflow-hidden">
                                                          <div className="entry-meta meta-1 font-x-small color-grey float-left text-uppercase">
                                                            {/* <span className="post-by">
                                                              By{" "}
                                                              <Link to="# ">
                                                                {
                                                                  post?.author_name
                                                                }
                                                              </Link>
                                                            </span> */}
                                                          </div>
                                                        </div>
                                                      </div>
                                                    </article>
                                                  )
                                              )}
                                            </div>
                                            <div className="d-flex">
                                              <div
                                                className="post-thumb d-flex mr-15
                                               border-radius-15 img-hover-scale"
                                              >
                                                <Link
                                                  className="color-white"
                                                  to={`/NewsDetails/${categoryResult?.id}`}
                                                >
                                                  {post?.file_type ==
                                                  "image" ? (
                                                    <img
                                                      className="border-radius-15"
                                                      style={{
                                                        width: "150px",
                                                        height: "150px",
                                                      }}
                                                      src={
                                                        post?.get_images?.image
                                                      }
                                                      alt=""
                                                    />
                                                  ) : (
                                                    <img
                                                      className="border-radius-15"
                                                      style={{
                                                        width: "150px",
                                                        height: "150px",
                                                      }}
                                                      src={post?.thumbnel}
                                                      alt=""
                                                    />
                                                  )}
                                                </Link>
                                              </div>
                                              <div className="post-content media-body">
                                                <h5 className="post-title mb-15 text-limit-2-row">
                                                  <span className="post-format-icon">
                                                    <i className="ti-camera"></i>
                                                  </span>
                                                  <Link
                                                    to={`/NewsDetails/${post?.id}`}
                                                  >
                                                    <span
                                                      style={{
                                                        color: `${post?.color_code}`,
                                                      }}
                                                    >
                                                      {post?.tags}
                                                    </span>
                                                    &nbsp;
                                                    {post?.title}
                                                  </Link>
                                                </h5>
                                                <div
                                                  className="entry-meta meta-1 font-x-small 
                                      color-grey float-left text-uppercase"
                                                >
                                                  <span
                                                    className="post-in font-x-small p-2 rounded-pill"
                                                    style={{
                                                      color: `${post?.color_code}`,
                                                    }}
                                                  >
                                                    {post?.tags}
                                                  </span>
                                                  <span className="post-by">
                                                    By{" "}
                                                    <Link to="#">
                                                      {post?.author_name}
                                                    </Link>
                                                  </span>
                                                  <span className="post-on">
                                                    {moment(
                                                      post?.created_at
                                                    ).format("DD-MM-YYYY")}
                                                  </span>
                                                  <span className="time-reading">
                                                    {post?.state}
                                                  </span>
                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                        )
                                      )}
                                    </div>
                                  </li>
                                </ul>
                              )}
                            </>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                  <div className="col-lg-4 col-md-12 sidebar-right">
                    <div className="sidebar-widget mb-50">
                      <div className="widget-header mb-30">
                        <h5 className="widget-title">
                          Most <span>Popular</span>
                        </h5>
                      </div>
                      <div className="post-aside-style-3">
                        {webDashBoard?.tranding_post?.map((result) => {
                          return (
                            <>
                              <article
                                className=" bg-white border-radius-15 mb-30 p-10 wow fadeIn animated"
                                // onClick={() => {
                                //   redirectToDetail(result?.id);
                                // }}
                              >
                                <div className="post-thumb mb-15 border-radius-15 img-hover-scale">
                                  <Link to={`/NewsDetails/${result?.id}`}>
                                    <img
                                      className="border-radius-15"
                                      src={result?.thumbnel}
                                      alt=""
                                    />
                                  </Link>
                                </div>
                                <div className="pl-10 pr-10">
                                  <h5 className="post-title mb-15">
                                    <Link to={`/NewsDetails/${result?.id}`}>
                                      {result?.title}
                                    </Link>
                                  </h5>
                                  <div className="entry-meta meta-1 font-x-small color-grey float-left text-uppercase mb-10">
                                    <span className="post-in">
                                      In{" "}
                                      <Link to={`/NewsDetails/${result?.id}`}>
                                        {result?.state}
                                      </Link>
                                    </span>
                                    <span className="post-by">
                                      By <Link to="#">Steven</Link>
                                    </span>
                                    <span className="post-on">
                                      {moment(result?.created_at).format(
                                        "DD-MM-YYYY"
                                      )}
                                    </span>
                                  </div>
                                </div>
                              </article>
                            </>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </main>
        )}

        {/* <!-- Footer Start--> */}
        <Footer />
      </div>
      {/* <!-- Main Wrap End--> */}
      <div className="dark-mark"></div>

      {showTopIcon ? (
        <Link
          id="scrollUp"
          to="/"
          onClick={scrollToTop}
          style={{ position: "fixed", zIndex: "2147483647" }}
        >
          <i className="ti-arrow-up"></i>
        </Link>
      ) : (
        <Link
          id="srollbottom"
          to="/"
          onClick={scrollToBottom}
          style={{ position: "fixed", zIndex: "2147483647" }}
        >
          <i className="ti-arrow-down"></i>
        </Link>
      )}
    </div>
  );
};
export default Home;
