import React, { useEffect, useState } from "react";
import "../../assets/css/color.css";
import "../../assets/css/responsive.css";
import "../../assets/css/widgets.css";
import "../../assets/css/style.css";
import { Link, useLocation, useParams } from "react-router-dom";
import Header from "../Header/Header";
import Footer from "../Footer/Footer";
import { API_BASE_URL } from "../../config/Config";
import axios from "axios";
import moment from "moment";
import { FaBars } from "react-icons/fa";
import ReactHtmlParser from "react-html-parser";
import CryptoJS from "crypto-js";
const NewsDetails = () => {
  // const location = useLocation();
  // const locationData = location.state.data;
  const [NewsDetails, setNewsDetails] = useState({});
  const [videoPath, setVideoPath] = useState("");
  // const [CategorieList, setCategorieList] = useState([]);
  // const [webDashBoard, setWebDashBoard] = useState({
  //   reals: [],
  //   posts: [],
  //   all_posts: [],
  //   slider: [],
  //   tranding_post: [],
  // });

  // useEffect(() => {
  //   console.log("locationData", locationData);
  // }, [locationData]);

  // const GetWebDashBoardCategory = async (id) => {
  //   await axios
  //     .get(`${API_BASE_URL}/web-dashboard?category_id=${id}`)
  //     .then((response) => {
  //       setWebDashBoard(response.data.data);
  //     })
  //     .catch((error) => {
  //       console.log(error);
  //     });
  // };
  // This Methods for the Get CateGoriesList
  // const GetCategorieList = async () => {
  //   await axios.get(`${API_BASE_URL}/category-list`).then((response) => {
  //     setCategorieList(response.data.data);
  //   });
  // };

  // Decode the URL-encoded parameter

  const { id } = useParams();
  useEffect(() => {
    const GetNewsDetails = async () => {
      let ApiData = {
        language: localStorage.getItem("lang")
          ? localStorage.getItem("lang")
          : "En",
      };
      axios
        .get(`${API_BASE_URL}/web-post-detail?id=${id}&language=${ApiData.language}`)
        .then((response) => {
          setNewsDetails(response.data);
          setVideoPath(response.data.data.vedio_file);
        })
        .catch((error) => {
          console.log(error);
        });
    };
    GetNewsDetails();
    // GetCategorieList();
  }, [id]);

  const [isCanvasOpen, setIsCanvasOpen] = useState(false);
  const toggleCanvas = () => {
    setIsCanvasOpen(!isCanvasOpen);
    console.log("isCanvasOpen", isCanvasOpen);
  };

  const closeCanvas = () => {
    console.log("out");
    setIsCanvasOpen(false);
  };

  return (
    <div>
      <div className={`main-wrap ${isCanvasOpen ? "canvas-opened" : ""}`}>
        {/* <!--Offcanvas sidebar--> */}
        {isCanvasOpen && (
          <aside
            id="sidebar-wrapper"
            className="custom-scrollbar p-5 offcanvas-sidebar position-right
                ps ps--active-x ps--active-y d-block d-md-none d-lg-none d-xl-none"
          >
            <button className="off-canvas-close" onClick={closeCanvas}>
              <i className="ti-close"></i>
            </button>
            <div className="sidebar-inner">
              <div className="sidebar-widget widget_categories border-radius-10 bg-white mb-30">
                <div className="widget-header position-relative mb-15">
                  <h5 className="widget-title">
                    <strong>Categories</strong>
                  </h5>
                </div>
                <div className="menu-container" onClick={closeCanvas}>
                  {/* This Map Methods for the CategoriesList Data  */}
                  {/* {CategorieList?.map((result) => {
                    return (
                      <>
                        <ul className="font-small text-muted">
                          <li className="cat-item cat-item-2">
                            <Link to="/">
                              <div
                                onClick={() =>
                                  GetWebDashBoardCategory(result?.id)
                                }
                              >
                                <img
                                  src={result?.image}
                                  style={{
                                    width: "30px",
                                    height: "30px",
                                    borderRadius: "50%",
                                    marginRight: "15px",
                                  }}
                                  alt=""
                                />
                                {result?.title}
                              </div>
                            </Link>
                          </li>
                        </ul>
                      </>
                    );
                  })} */}
                </div>
              </div>
            </div>
            <div className="ps__rail-x">
              <div class="ps__thumb-x"></div>
            </div>
            <div className="ps__rail-y">
              <div className="ps__thumb-y"></div>
            </div>
          </aside>
        )}
        {/* <!-- Main Header --> */}
        <Header />
        {/* off-canvas-toggle-cover */}
        <div className="off-canvas-toggle-cover">
          <div
            className="off-canvas-toggle hidden d-inline-block
                                         ml-15"
            id="off-canvas-toggle"
          >
            <FaBars
              name="grid-outline"
              onClick={toggleCanvas}
              role="img"
              className="md hydrated  d-block d-md-none d-lg-none d-xl-none"
              aria-label="grid outline"
            />
          </div>
        </div>
        {/* <!-- Main Wrap Start --> */}

        <main
          className="position-relative"
          style={{ transform: "none", marginTop: "100px" }}
        >
          <div className="container" style={{ transform: "none" }}>
            <div className="entry-header entry-header-1 mb-30 mt-50">
              <div className="entry-meta meta-0 font-small mb-30">
                <Link to="/">
                  <span className="post-cat bg-success color-white">
                    {NewsDetails?.data?.tags}
                  </span>
                </Link>
              </div>
              <h1 className="post-title mb-30">{NewsDetails?.data?.title}</h1>
              <div className="entry-meta meta-1 font-x-small color-grey text-uppercase">
                <span className="post-by">
                  By <Link to="#">{NewsDetails?.data?.author_name} </Link> &amp;
                  <Link to="/">{NewsDetails?.data?.author_name}</Link>
                </span>
                <span className="post-on">
                  {moment(NewsDetails?.data?.created_at).format("DD-MM-YYYY")}
                </span>
                <p className="font-x-small mt-10">
                  <span className="hit-count">
                    <i className="ti-comment mr-5"></i>
                    {NewsDetails?.data?.comment_count}
                  </span>
                  {/* <span className="hit-count">
                    <i className="fas fa-eye mr-5"></i>
                    {NewsDetails?.data?.views_count}
                  </span> */}
                  <span className="hit-count">
                    <i className="ti-star mr-5"></i>
                    {NewsDetails?.data?.state}
                  </span>
                  <span className="hit-count">
                    <i className="ti-harddrives mr-5"></i>
                    {NewsDetails?.data?.get_category?.title}
                  </span>
                </p>
              </div>
            </div>
            {/* <!--end entry header--> */}
            <div className="row mb-50" style={{ transform: "none" }}>
              <div className="col-lg-8 col-md-12 ">
                {/* <div className="single-social-share single-sidebar-share mt-30 ml-4">
                  <ul>
                    <li>
                      <Link
                        className="social-icon facebook-icon text-xs-center"
                        target="_blank"
                        to="/"
                      >
                        <i className="ti-facebook"></i>
                      </Link>
                    </li>
                    <li>
                      <Link
                        className="social-icon twitter-icon text-xs-center"
                        target="_blank"
                        to="/"
                      >
                        <i className="ti-twitter-alt"></i>
                      </Link>
                    </li>
                    <li>
                      <Link
                        className="social-icon pinterest-icon text-xs-center"
                        target="_blank"
                        to="/"
                      >
                        <i className="ti-pinterest"></i>
                      </Link>
                    </li>
                    <li>
                      <Link
                        className="social-icon instagram-icon text-xs-center"
                        target="_blank"
                        to="/"
                      >
                        <i className="ti-instagram"></i>
                      </Link>
                    </li>
                    <li>
                      <Link
                        className="social-icon linkedin-icon text-xs-center"
                        target="_blank"
                        to="/"
                      >
                        <i className="ti-linkedin"></i>
                      </Link>
                    </li>
                    <li>
                      <Link
                        className="social-icon email-icon text-xs-center"
                        target="_blank"
                        to="/"
                      >
                        <i className="ti-email"></i>
                      </Link>
                    </li>
                  </ul>
                </div> */}
                <div className="bt-1 border-color-1 mb-30 "></div>
                <div>
                  {NewsDetails?.data ? (
                    NewsDetails?.data?.file_type === "videos" ? (
                      <video
                        controls
                        poster={NewsDetails?.data?.thumbnel}
                        autoplay
                        className="photo-item__video NewsDetailsVideos"
                        loop
                        muted
                        preload="auto"
                      >
                        <source src={videoPath} type="video/mp4" />
                      </video>
                    ) : (
                      <img
                        src={NewsDetails?.data?.get_images[0]?.image}
                        alt="post-slider"
                        style={{
                          width: "100%",
                          height: "80vh",
                          objectFit: "cover",
                        }}
                      />
                    )
                  ) : (
                    <figure className="single-thumnail mb-30">
                      <img
                        src={NewsDetails?.data?.thumbnel}
                        alt=""
                        style={{ width: "100%" }}
                      />
                      <div className="credit mt-15 font-small color-grey">
                        <i className="ti-credit-card mr-5"></i>
                      </div>
                    </figure>
                  )}
                </div>

                <div className="single-excerpt"></div>
                <div className="entry-main-content">
                  {/* <h2>Design is future</h2> */}
                  <hr className="wp-block-separator is-style-wide" />
                  {ReactHtmlParser(NewsDetails?.data?.short_decription)}
                </div>

                {/* <!--author box--> */}

                {/* <!--related posts--> */}
                {/* <div className="related-posts">
                  <h3 className="mb-30">Related posts</h3>
                  <div className="row">
                    <article className="col-lg-4">
                      <div className="background-white border-radius-10 p-10 mb-30">
                        <div
                          className="post-thumb d-flex mb-15 border-radius-15
                                         img-hover-scale"
                        >
                          <Link to="/">
                            <img
                              className="border-radius-15"
                              src={news1}
                              alt=""
                            />
                          </Link>
                        </div>
                        <div className="pl-10 pr-10">
                          <div className="entry-meta mb-15 mt-10">
                            <Link className="entry-meta meta-2" to="/">
                              <span className="post-in text-primary font-x-small">
                                Politic
                              </span>
                            </Link>
                          </div>
                          <h5 className="post-title mb-15">
                            <span className="post-format-icon">
                              <ion-icon
                                name="image-outline"
                                role="img"
                                className="md hydrated"
                                aria-label="image outline"
                              ></ion-icon>
                            </span>
                            <Link to="/">
                              The litigants on the screen are not actors
                            </Link>
                          </h5>
                          <div className="entry-meta meta-1 font-x-small color-grey float-left text-uppercase mb-10">
                            <span className="post-by">
                              By <Link to="#">John Nathan</Link>
                            </span>
                            <span className="post-on">8m ago</span>
                          </div>
                        </div>
                      </div>
                    </article>
                    <article className="col-lg-4">
                      <div className="background-white border-radius-10 p-10 mb-30">
                        <div className="post-thumb d-flex mb-15 border-radius-15 img-hover-scale">
                          <Link to="/">
                            <img
                              className="border-radius-15"
                              src={news1}
                              alt=""
                            />
                          </Link>
                        </div>
                        <div className="pl-10 pr-10">
                          <div className="entry-meta mb-15 mt-10">
                            <Link className="entry-meta meta-2" to="/">
                              <span className="post-in text-success font-x-small">
                                Tech
                              </span>
                            </Link>
                          </div>
                          <h5 className="post-title mb-15">
                            <span className="post-format-icon">
                              <ion-icon
                                name="headset-outline"
                                role="img"
                                className="md hydrated"
                                aria-label="headset outline"
                              ></ion-icon>
                            </span>
                            <Link to="/">
                              Essential Qualities of Highly Successful Music
                            </Link>
                          </h5>
                          <div className="entry-meta meta-1 font-x-small color-grey float-left text-uppercase mb-10">
                            <span className="post-by">
                              By <Link to="/">K. Steven</Link>
                            </span>
                            <span className="post-on">24m ago</span>
                          </div>
                        </div>
                      </div>
                    </article>
                    <article className="col-lg-4">
                      <div className="background-white border-radius-10 p-10">
                        <div className="post-thumb d-flex mb-15 border-radius-15 img-hover-scale">
                          <Link to="/">
                            <img
                              className="border-radius-15"
                              src={news1}
                              alt=""
                            />
                          </Link>
                        </div>
                        <div className="pl-10 pr-10">
                          <div className="entry-meta mb-15 mt-10">
                            <Link className="entry-meta meta-2" to="/">
                              <span className="post-in text-danger font-x-small">
                                Global
                              </span>
                            </Link>
                          </div>
                          <h5 className="post-title mb-15">
                            <Link to="/">
                              Essential Qualities of Highly Successful Music
                            </Link>
                          </h5>
                          <div className="entry-meta meta-1 font-x-small color-grey float-left text-uppercase mb-10">
                            <span className="post-by">
                              By <Link to="/">K. Jonh</Link>
                            </span>
                            <span className="post-on">24m ago</span>
                          </div>
                        </div>
                      </div>
                    </article>
                  </div>
                </div> */}
              </div>
              {/* <!--End col-lg-8--> */}
              <div className="col-lg-4 col-md-12 sidebar-right">
                <div className="sidebar-widget mb-50">
                  <div className="widget-header mb-30"></div>
                  {/* <div className="post-aside-style-3">
                    <article className="bg-white border-radius-15 mb-30 p-10 wow fadeIn animated">
                      <div className="post-thumb d-flex mb-15 border-radius-15 img-hover-scale">
                        <video
                          controls
                          poster={NewsDetails?.data?.thumbnel}
                          autoplay
                          className="photo-item__video"
                          loop
                          muted
                          preload="auto"
                        >
                          <source src={videoPath} type="video/mp4" />
                        </video>
                      </div>
                      <div className="pl-10 pr-10">
                        <h5 className="post-title mb-15">
                          <Link to="/">{NewsDetails?.data?.title}</Link>
                        </h5>
                        <div className="entry-meta meta-1 font-x-small color-grey float-left text-uppercase mb-10">
                          <span className="post-in">
                            In <Link to="/">{NewsDetails?.data?.state}</Link>
                          </span>
                          <span className="post-by">
                            By{" "}
                            <Link to="/">{NewsDetails?.data?.author_name}</Link>
                          </span>
                        </div>
                      </div>
                    </article>                   
                  </div> */}
                </div>
                <div className="sidebar-widget p-20 border-radius-15 bg-white widget-latest-comments wow fadeIn animated">
                  <div className="widget-header mb-30">
                    <h5 className="widget-title">
                      Last <span>Comments</span>
                    </h5>
                  </div>
                  <div className="post-block-list post-module-6">
                    {NewsDetails?.postComment?.map((Commentresult) => {
                      return (
                        <>
                          <div className="last-comment mb-20 d-flex wow fadeIn animated">
                            <span className="item-count vertical-align">
                              <Link
                                className="red-tooltip author-avatar"
                                to="#"
                              >
                                <img
                                  src={Commentresult?.get_user?.profile}
                                  alt=""
                                />
                              </Link>
                            </span>
                            <div className="alith_post_title_small">
                              <p className="font-medium mb-10">
                                {Commentresult?.comment}
                              </p>
                              <div class="entry-meta meta-1 font-x-small color-grey float-left text-uppercase mb-10">
                                <span className="post-by">
                                  By{" "}
                                  <Link to="/ ">
                                    {Commentresult?.get_user?.name}{" "}
                                    {Commentresult?.get_user?.lname}
                                  </Link>
                                </span>
                                <span className="post-on">
                                  {" "}
                                  {moment(Commentresult?.created_at).format(
                                    "DD-MM-YYYY H:i"
                                  )}
                                </span>
                              </div>
                            </div>
                          </div>
                        </>
                      );
                    })}
                  </div>
                </div>
              </div>
              {/* <!--End col-lg-4--> */}
            </div>
            {/* <!--End row--> */}
          </div>
        </main>
        {/* <!-- Footer Start--> */}
        <Footer />
      </div>
      {/* <!-- Main Wrap End--> */}
      <div className="dark-mark"></div>
      <Link
        id="scrollUp"
        to="#top"
        style={{ display: "none", position: "fixed", zIndex: "214783647" }}
      >
        <i className="ti-arrow-up"></i>
      </Link>
    </div>
  );
};

export default NewsDetails;
