const API_BASE_URL = "https://rasatva.apponedemo.top/news/api";

export {API_BASE_URL};